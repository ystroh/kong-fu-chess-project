package com.chessgame;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.PrintStream;
import java.nio.charset.StandardCharsets;

import static org.junit.jupiter.api.Assertions.assertEquals;

/**
 * AppTest / טסטים ל-App
 *
 * זה בדיוק הטסט שהיה-מונע-מראש את הבאג-שכבר-קרה-בפועל (Main.java
 * ריק, לא-עושה-כלום). מריץ את App.run() *ממש* מקצה-לקצה, דרך
 * System.in/System.out מדומים (בלי טרמינל-אמיתי) - בדיוק כמו
 * שהפלטפורמה (ultracode) מריצה את התוכנית. אם מישהו "ישבור" את
 * App/Main שוב בעתיד, הטסט הזה יתפוס-את-זה מיד ב-mvn test, לא רק
 * אחרי-הגשה-לפלטפורמה.
 *
 * הערה: לא בודקים כאן תרחיש-שגיאת-פרסינג (UNKNOWN_TOKEN וכו') - כי
 * App.buildDispatcher קורא ל-System.exit(0) על שגיאה, וזה היה
 * מפיל את כל-ריצת-הטסטים-בתהליך (לא רק את הטסט-הזה). זו מגבלה
 * ידועה של App כמו-שהוא בנוי היום - System.exit() בתוך קוד-לוגי
 * הוא בעצמו "ריח" ארכיטקטוני, אבל תיקון-זה מחוץ-לתחום-הטסט-הזה.
 */
class AppTest {

    private InputStream originalIn;
    private PrintStream originalOut;

    @BeforeEach
    void saveOriginalStreams() {
        originalIn = System.in;
        originalOut = System.out;
    }

    @AfterEach
    void restoreOriginalStreams() {
        System.setIn(originalIn);
        System.setOut(originalOut);
    }

    @Test
    void fullPipeline_parsesBoardExecutesCommandsAndPrintsResult() {
        String input = " Board:\nwK . .\n. . .\n. . bK\nCommands:\nclick 50 50\nclick 150 150\nwait 1000\nprint board\n";

        String output = runAppWith(input);

        assertEquals(". . .\n. wK .\n. . bK\n", output);
    }

    @Test
    void collisionAndCooldownWorkThroughTheRealPipeline() {
        // בדיוק התרחיש שכבר בדקנו ידנית הרבה פעמים לאורך השיחה -
        // עכשיו כטסט-קבוע, דרך *כל* השרשרת האמיתית (App->GameSession
        // ->Controller->GameEngine->RealTimeArbiter->CollisionManager)
        String input = " Board:\nwR bP .\nCommands:\nclick 50 50\nclick 250 50\nwait 2000\nprint board\n";

        String output = runAppWith(input);

        assertEquals(". . wR\n", output);
    }

    private String runAppWith(String input) {
        System.setIn(new ByteArrayInputStream(input.getBytes(StandardCharsets.UTF_8)));
        ByteArrayOutputStream captured = new ByteArrayOutputStream();
        System.setOut(new PrintStream(captured, true, StandardCharsets.UTF_8));

        new App().run();

        System.out.flush();
        // println() מוסיף את מפריד-השורה של מערכת-ההפעלה (Windows: \r\n,
        // Linux/Mac: \n) - מנרמלים כאן כדי שהטסט יעבוד זהה בכל סביבה.
        String raw = captured.toString(StandardCharsets.UTF_8);
        return raw.replace("\r\n", "\n");
    }
}