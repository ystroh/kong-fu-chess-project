package com.chessgame.realtime.cooldown;

import com.chessgame.model.Piece;
import com.chessgame.model.Position;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/**
 * CooldownManager / מנהל-קירור
 *
 * תפקיד: "בעלים" של רשימת הכלים-בקירור - בדיוק אותה תבנית כמו
 * AirborneManager (רשימה + זמן-פקיעה + בדיקת-עסוק). אחרי שכלי מסיים
 * תנועה בהצלחה, הוא לא הופך ל-IDLE מיד - הוא עובר תחילה לקירור,
 * וחוזר ל-IDLE רק כשזמן-הקירור פוקע.
 */
public final class CooldownManager {
    private final long cooldownDurationMs;
    private final List<CooldownEntry> entries = new ArrayList<>();

    public CooldownManager(long cooldownDurationMs) {
        this.cooldownDurationMs = cooldownDurationMs;
    }

    /** האם הכלי בתא הנתון נמצא כרגע בקירור. */
    public boolean isPieceCoolingDown(Position position) {
        for (CooldownEntry entry : entries) {
            if (entry.piece.cell().equals(position)) return true;
        }
        return false;
    }

    /** מתחיל קירור לכלי נתון, ומעדכן את מצבו ל-COOLDOWN. */
    public void startCooldown(Piece piece, long gameClock) {
        piece.setState(Piece.State.COOLDOWN);
        entries.add(new CooldownEntry(piece, gameClock + cooldownDurationMs));
    }

    /** מנקה כל קירור שפג-זמנו, ומחזיר את הכלים המתאימים ל-IDLE. */
    public void clearExpiredCooldowns(long gameClock) {
        Iterator<CooldownEntry> it = entries.iterator();
        while (it.hasNext()) {
            CooldownEntry entry = it.next();
            if (gameClock >= entry.expireTime) {
                entry.piece.setState(Piece.State.IDLE);
                it.remove();
            }
        }
    }
}
