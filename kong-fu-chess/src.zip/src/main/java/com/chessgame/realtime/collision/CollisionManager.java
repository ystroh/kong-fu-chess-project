package com.chessgame.realtime.collision;

import com.chessgame.model.Board;
import com.chessgame.model.Piece;
import com.chessgame.model.Position;
import com.chessgame.realtime.motion.Motion;
import com.chessgame.realtime.motion.MotionManager;

import java.util.ArrayList;
import java.util.List;

/**
 * CollisionManager / מנהל-התנגשויות
 *
 * תפקיד: "מתאם דק" - מחזיק תור-מועמדים (CollisionCandidate, לא
 * משנה-איזה-סוג-בדיוק), ודואג לרישום ולעיבוד-כרונולוגי. לא-יודע
 * *כלום* על ההבדל בין שלושת-הסוגים - כל מועמד יודע-להסביר-על-עצמו
 * (isStillRelevant, resolve). זה מחליף לגמרי את CollisionResolver
 * הקודם - אין יותר צורך בו, כי כל מועמד "פותר את עצמו".
 */
public final class CollisionManager {
    private final Board board;
    private final MotionManager motionManager;
    private final long cellDurationMs;
    private final List<CollisionCandidate> pending = new ArrayList<>();

    public CollisionManager(Board board, MotionManager motionManager, long cellDurationMs) {
        this.board = board;
        this.motionManager = motionManager;
        this.cellDurationMs = cellDurationMs;
    }

    /**
     * בודקת תנועה-חדשה משני כיוונים: (1) מול כל תנועה-אחרת-שכבר-
     * פעילה - חפיפת-מסלול רגילה (בוחרת EnemyMotionCollision או
     * FriendlyMotionCollision, לפי-צבע). (2) מול הלוח-הנוכחי -
     * אויבים-דוממים על-המסלול (StationaryBlockerCollision).
     */
    public void registerIfColliding(Motion newMotion, List<Motion> currentlyActive) {
        if (newMotion.piece().kind() == Piece.Kind.KNIGHT) return;

        for (Motion existing : currentlyActive) {
            if (existing.piece().kind() == Piece.Kind.KNIGHT) continue;

            Position sharedCell = CollisionGeometry.findSharedCell(newMotion, existing);
            if (sharedCell == null) continue;

            long timeNew = CollisionGeometry.arrivalTimeAt(newMotion, sharedCell, cellDurationMs);
            long timeExisting = CollisionGeometry.arrivalTimeAt(existing, sharedCell, cellDurationMs);
            long eventTime = Math.max(timeNew, timeExisting);

            if (newMotion.piece().isSameColorAs(existing.piece())) {
                pending.add(new FriendlyMotionCollision(eventTime, newMotion, existing, sharedCell, timeNew, timeExisting, cellDurationMs));
            } else {
                pending.add(new EnemyMotionCollision(eventTime, newMotion, existing));
            }
        }

        registerStationaryBlockers(newMotion);
    }

    private void registerStationaryBlockers(Motion newMotion) {
        List<Position> path = CollisionGeometry.pathExcludingDestination(newMotion.source(), newMotion.destination());
        for (Position cell : path) {
            Piece occupant = board.pieceAt(cell);
            if (occupant == null) continue;
            if (motionManager.isPieceMoving(cell)) continue;
            if (!occupant.isEnemyOf(newMotion.piece())) continue;

            long eventTime = CollisionGeometry.arrivalTimeAt(newMotion, cell, cellDurationMs);
            pending.add(new StationaryBlockerCollision(eventTime, newMotion, occupant, cell));
        }
    }

    /**
     * מקדמת את הטיפול-בהתנגשויות עד לזמן-המשחק הנתון: אוספת מועמדים
     * שהגיע-זמנם, ממיינת כרונולוגית, ומעבדת אחד-אחד - שואלת כל
     * מועמד "עדיין-רלוונטי?" ו"תפעיל-את-עצמך", בלי לדעת מה-בדיוק-הוא.
     */
    public boolean resolveDue(long gameClock) {
        List<CollisionCandidate> due = new ArrayList<>();
        for (CollisionCandidate candidate : pending) {
            if (candidate.eventTime() <= gameClock) due.add(candidate);
        }
        due.sort((a, b) -> Long.compare(a.eventTime(), b.eventTime()));
        pending.removeAll(due);

        boolean kingCaptured = false;
        for (CollisionCandidate candidate : due) {
            if (candidate.isStillRelevant(motionManager, board)) {
                kingCaptured |= candidate.resolve(board, motionManager);
            }
        }
        return kingCaptured;
    }
}
