package com.chessgame.realtime.collision;

import com.chessgame.model.Position;
import com.chessgame.realtime.motion.Motion;

import java.util.ArrayList;
import java.util.List;

/**
 * CollisionGeometry / גיאומטריית-התנגשויות
 *
 * תפקיד: חישובים גיאומטריים-טהורים בלבד - בלי שום מצב, בלי שום
 * "החלטה" (לא קובעת מי-מנצח, לא נוגעת בלוח). רק מתמטיקה: איפה
 * מסלולים חוצים, מתי כל תנועה מגיעה לתא מסוים, מה התא-שלפני-תא.
 * בדיוק כמו SlidingMovement (ב-rules) - כלי-עזר סטטי, לא מחלקה
 * עם state משל עצמה.
 */
final class CollisionGeometry {
    private CollisionGeometry() {}

    /** נתיב-המסלול *לא-כולל* את היעד-הסופי (שם מטפלת לכידה-רגילה, לא כאן). */
    static List<Position> pathExcludingDestination(Position source, Position destination) {
        List<Position> full = fullPathInclusive(source, destination);
        return full.subList(0, full.size() - 1);
    }

    /** המשבצת-הראשונה-המשותפת (אם יש) בין המסלולים של שתי תנועות. */
    static Position findSharedCell(Motion a, Motion b) {
        List<Position> pathA = fullPathInclusive(a.source(), a.destination());
        List<Position> pathB = fullPathInclusive(b.source(), b.destination());
        for (Position cell : pathA) {
            if (pathB.contains(cell)) return cell;
        }
        return null;
    }

    /** זמן-ההגעה של תנועה נתונה למשבצת-ספציפית-במסלול-שלה (לאו-דווקא היעד-הסופי). */
    static long arrivalTimeAt(Motion motion, Position cell, long cellDurationMs) {
        int distance = chebyshevDistance(motion.source(), cell);
        return motion.startTime() + distance * cellDurationMs;
    }

    /** המשבצת-שלפני cell, על-המסלול-של motion (בכיוון-התנועה-שלו-עצמו). */
    static Position cellBeforeSharedCell(Motion motion, Position sharedCell) {
        int stepRow = Integer.compare(motion.destination().row(), motion.source().row());
        int stepCol = Integer.compare(motion.destination().col(), motion.source().col());
        return new Position(sharedCell.row() - stepRow, sharedCell.col() - stepCol);
    }

    /** נתיב מלא (כולל קצוות) בין שתי נקודות, בקו-ישר/אלכסון (פרשים כבר מסוננים לפני שמגיעים לכאן). */
    private static List<Position> fullPathInclusive(Position from, Position to) {
        int stepRow = Integer.compare(to.row(), from.row());
        int stepCol = Integer.compare(to.col(), from.col());
        List<Position> path = new ArrayList<>();
        int row = from.row(), col = from.col();
        while (row != to.row() || col != to.col()) {
            path.add(new Position(row, col));
            row += stepRow; col += stepCol;
        }
        path.add(new Position(to.row(), to.col()));
        return path;
    }

    private static int chebyshevDistance(Position a, Position b) {
        return Math.max(Math.abs(a.row() - b.row()), Math.abs(a.col() - b.col()));
    }
}
