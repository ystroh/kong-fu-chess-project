package com.chessgame.realtime.collision;

import com.chessgame.model.Board;
import com.chessgame.realtime.motion.MotionManager;

/**
 * CollisionCandidate / מועמד-להתנגשות
 *
 * תפקיד: כל סוג-התנגשות (אויבים-נעים, ידידים-נעים, אויב-דומם)
 * מממש את הממשק הזה בעצמו - יודע להסביר-על-עצמו "מתי אני קורה",
 * "האם אני עדיין רלוונטי", ו"מה קורה כשמפעילים אותי". בלי null,
 * בלי boolean-דגל שמסתיר איזה-סוג-זה - כל סוג הוא מחלקה נפרדת,
 * ו-CollisionManager לא צריך לדעת בכלל כמה-סוגים-קיימים.
 */
interface CollisionCandidate {
    long eventTime();

    boolean isStillRelevant(MotionManager motionManager, Board board);

    /** מבצע בפועל. מחזיר true אם הביא ללכידת-מלך. */
    boolean resolve(Board board, MotionManager motionManager);
}
