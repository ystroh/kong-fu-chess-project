package com.chessgame.realtime.cooldown;

import com.chessgame.model.Piece;

/** CooldownEntry / רשומת-קירור - דאטה בלבד: כלי + זמן-סיום-הקירור. */
final class CooldownEntry {
    final Piece piece;
    final long expireTime;

    CooldownEntry(Piece piece, long expireTime) {
        this.piece = piece;
        this.expireTime = expireTime;
    }
}
