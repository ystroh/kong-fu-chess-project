package com.chessgame.realtime.collision;

import com.chessgame.model.Board;
import com.chessgame.model.Position;
import com.chessgame.realtime.motion.Motion;
import com.chessgame.realtime.motion.MotionManager;

/**
 * FriendlyMotionCollision / התנגשות-ידידים-נעים
 *
 * תפקיד: שני כלים-מאותו-הצד, שניהם-בתנועה, שמסלוליהם חוצים. מי-
 * שהיה-מגיע-*למשבצת-המשותפת*-מאוחר-יותר נעצר - משבצת-אחת-לפני,
 * על-המסלול-שלו-עצמו. השני ממשיך ליעד-המקורי-שלו ללא שינוי.
 */
final class FriendlyMotionCollision implements CollisionCandidate {
    private final long eventTime;
    private final Motion motionA;
    private final Motion motionB;
    private final Position sharedCell;
    private final long timeAtCellA;
    private final long timeAtCellB;
    private final long cellDurationMs;

    FriendlyMotionCollision(long eventTime, Motion motionA, Motion motionB, Position sharedCell,
                             long timeAtCellA, long timeAtCellB, long cellDurationMs) {
        this.eventTime = eventTime;
        this.motionA = motionA;
        this.motionB = motionB;
        this.sharedCell = sharedCell;
        this.timeAtCellA = timeAtCellA;
        this.timeAtCellB = timeAtCellB;
        this.cellDurationMs = cellDurationMs;
    }

    @Override
    public long eventTime() {
        return eventTime;
    }

    @Override
    public boolean isStillRelevant(MotionManager motionManager, Board board) {
        return motionManager.isStillActive(motionA) && motionManager.isStillActive(motionB);
    }

    @Override
    public boolean resolve(Board board, MotionManager motionManager) {
        boolean aArrivesLater = timeAtCellA > timeAtCellB;
        Motion stopping = aArrivesLater ? motionA : motionB;

        Position cellBefore = CollisionGeometry.cellBeforeSharedCell(stopping, sharedCell);
        long stopArrivalTime = CollisionGeometry.arrivalTimeAt(stopping, cellBefore, cellDurationMs);
        Motion truncated = new Motion(stopping.source(), cellBefore, stopping.piece(), stopping.startTime(), stopArrivalTime);

        motionManager.replace(stopping, truncated);
        return false;
    }
}
