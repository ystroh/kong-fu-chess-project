package com.chessgame.ui;

import javax.swing.*;
import java.awt.*;
import java.awt.image.BufferedImage;

// אנחנו מייצרים לוח ציור משלנו
public class ChessBoardPanel extends JPanel {
    private BufferedImage currentBoardImage; // מחזיק את התמונה הנוכחית של הלוח

    // בכל פעם שמצב המשחק משתנה, נעדכן את התמונה ונגיד לפאנל לצייר את עצמו מחדש
    public void setBoardImage(Img img) {
        // כאן חובה להשתמש ב-get()! כי paintComponent דורשת BufferedImage גולמי
        this.currentBoardImage = img.get();

        // קורא ל-paintComponent מאחורי הקלעים ומעדכן את המסך
        repaint();
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g); // מנקה את הרקע הקודם

        if (currentBoardImage != null) {
            // מצייר את התמונה הגולמית על פני כל הפאנל בנקודה 0,0
            g.drawImage(currentBoardImage, 0, 0, this);
        }
    }
}
