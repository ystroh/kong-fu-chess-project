package com.chessgame.ui;

import com.chessgame.model.Position;
import java.awt.Point;

public final class UiMapper {
    private final int CELL_SIZE = 100 ; // גודל משבצת יחידה בפיקסלים (למשל: 100)

    public UiMapper() {

    }

    public int getCellSize() {
        return CELL_SIZE;
    }

    /**
     * המרה ממיקום לוגי (Position) לפיקסלים על המסך (עבור הציור).
     * שימי לב להצלבה החשובה:
     * col (עמודה אופקית) -> ציר X
     * row (שורה אנכית)   -> ציר Y
     */
    public Point cellToPixel(Position pos) {
        int x = pos.col() * CELL_SIZE;
        int y = pos.row() * CELL_SIZE;
        return new Point(x, y);
    }

    /**
     * המרה מקליק בעכבר (פיקסלים) בחזרה למיקום לוגי על הלוח.
     */
    public Position pixelToCell(int x, int y) {
        if (x < 0 || y < 0) return null;
        return new Position(y / CELL_SIZE, x / CELL_SIZE);
    }
}
