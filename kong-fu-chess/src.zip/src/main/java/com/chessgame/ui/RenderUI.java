package com.chessgame.ui;

import com.chessgame.engine.GameSnapshot;
import com.chessgame.model.Piece;

import java.awt.*;
import java.awt.image.BufferedImage;

public final  class RenderUI {

    private final UiMapper  mapper;
    // נתיב לתמונת הרקע של הלוח הריק (יש לעדכן בהתאם למיקום הקבצים שלך)
    private static final String BOARD_IMAGE_PATH = "src/main/resources/board.png";

    public RenderUI(UiMapper mapper) {
        this.mapper = mapper;
    }

    /**
     * מקבלת את מצב המשחק (Snapshot) ומחזירה תמונה (BufferedImage) מעודכנת של הלוח.
     */
    public BufferedImage renderNewFrame(GameSnapshot snapshot) {
        // 1. טעינת תמונת הרקע של הלוח למחלקת Img
        Img finalBoardImage = new Img().read(BOARD_IMAGE_PATH);

        // TODO: ציור סימון המשבצת הנבחרת (selectedCell) על לוח הרקע
        // כרגע נשאיר ריק. אם נרצה לצייר ריבוע ירוק, נוכל להשתמש ב-Graphics2D של finalBoardImage.get()
        // או לצייר תמונה חצי-שקופה של "ריבוע מסומן" בעזרת finalBoardImage.drawOn(...)

        // 2. ציור הכלים על גבי הלוח
        for (GameSnapshot.PieceView piece : snapshot.pieces()) {
            Point pixel = mapper.cellToPixel(piece.position());

            // מציאת הנתיב של התמונה הספציפית לכלי זה
            String pieceImagePath = getPieceImagePath(piece);

            if (pieceImagePath != null) {
                // טעינת תמונת הכלי
                Img pieceImg = new Img().read(pieceImagePath);

                // ציור (הדבקת) תמונת הכלי על תמונת הלוח במיקום הפיקסלים המדויק
                pieceImg.drawOn(finalBoardImage, pixel.x, pixel.y);
            }
        }

        // 3. הוספת טקסט סיום משחק (אם רלוונטי) ישירות דרך Img
        if (snapshot.isGameOver()) {
            String winnerText = "GAME OVER";
            if (snapshot.winner() != null) {
                winnerText += " - " + (snapshot.winner() == Piece.Color.WHITE ? "White Wins!" : "Black Wins!");
            }
            // מצייר טקסט במרכז העליון של הלוח (הקואורדינטות להמחשה)
            finalBoardImage.putText(winnerText, 50, 50, 2.0f, Color.RED, 1);
        }

        // 4. שליפת האובייקט הפנימי (BufferedImage) מה-Img כדי להחזיר ל-Window
        return finalBoardImage.get();
    }

    /**
     * פונקציית עזר המחזירה את הנתיב (Path) בקבצי המערכת לתמונה של כלי מסוים.
     * במקום לקרוא לפונקציית ציור, היא רק ממפה בין מצב הכלי לבין שם הקובץ.
     */
    private String getPieceImagePath(GameSnapshot.PieceView piece) {
        // TODO: כאן נצטרך לכתוב את הלוגיקה שתחליט איזה קובץ לטעון!
        // לדוגמה, אם הקבצים מסודרים לפי תבנית מסוימת:
        // String colorName = piece.color() == Piece.Color.WHITE ? "white" : "black";
        // String kindName = piece.kind().name().toLowerCase();
        // return "src/main/resources/pieces/" + colorName + "_" + kindName + ".png";

        return null; // מוחזר null זמנית עד שנוסיף את הלוגיקה
    }
}